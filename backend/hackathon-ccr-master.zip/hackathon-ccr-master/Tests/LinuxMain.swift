import XCTest

import backend_swiftTests

var tests = [XCTestCaseEntry]()
tests += backend_swiftTests.allTests()
XCTMain(tests)
