//
//  Authenticate.swift
//  backend-swift
//
//  Created by Isaac Douglas on 14/06/20.
//

import Foundation

struct Authenticate: Codable {
    var username: String
    var password: String
}
